package org.example.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;
import java.util.stream.Collectors;

@DefaultUrl("https://www.emag.ro/")
public class EmagPage extends PageObject {

    @FindBy(id="searchboxTrigger")
    private WebElementFacade searchInput;

    @FindBy(css=".searchbox-submit-button")
    private WebElementFacade searchButton;

    public void enter_keywords(String keyword) {
        searchInput.type(keyword);
    }

    public void lookup_terms() {
        searchButton.click();
    }

    public List<String> getProductFeatures() {
        WebElementFacade productsList = find(By.cssSelector(".card-v2"));
        return productsList.findElements(By.cssSelector(".card-v2-title")).stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    public void acceptCookiesIfPresent() {
        try {
            WebElementFacade cookieAcceptButton = find(By.cssSelector(".cookie-banner-buttons .btn-primary"));
            if (cookieAcceptButton.isVisible()) {
                cookieAcceptButton.click();
                waitFor(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".cookie-banner-content")));
                evaluateJavascript("window.scrollBy(0, 500)");
            }
        } catch (Exception e) {
            System.out.println("Cookie banner not present or already handled.");
        }
    }

    public void addFirstProductToCart() {
        acceptCookiesIfPresent();
        WebElementFacade firstAddToCartButton = find(By.cssSelector(".btn-primary.btn-sm"));
        waitFor(ExpectedConditions.elementToBeClickable(firstAddToCartButton));
        firstAddToCartButton.click();
    }
}
