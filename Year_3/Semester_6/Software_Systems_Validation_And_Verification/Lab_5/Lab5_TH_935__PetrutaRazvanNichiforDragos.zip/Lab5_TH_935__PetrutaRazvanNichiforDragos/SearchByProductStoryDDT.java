package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.Qualifier;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.EmagUserSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/eMAGTestData.csv")
public class SearchByProductStoryDDT {
    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public EmagUserSteps endUser;

    public String productName;
    public String expectedFeature;

    @Qualifier
    public String getQualifier() {
        return productName;
    }

    @Test
    public void searchProductByKeywordTestDDT() {
        endUser.is_the_home_page();
        endUser.looks_for(productName);
        endUser.should_see_feature(expectedFeature);
    }

    @Test
    public void shouldAddProductToCart() {
        endUser.is_the_home_page();
        endUser.enters("laptop");
        endUser.starts_search();
        endUser.adds_first_product_to_cart();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getExpectedFeature() {
        return expectedFeature;
    }

    public void setExpectedFeature(String expectedFeature) {
        this.expectedFeature = expectedFeature;
    }
}
